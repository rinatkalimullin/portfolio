Home assignment done by Rinat Kalimullin.
Group: CIE 22-02
Section: 001
Student ID: U2210099